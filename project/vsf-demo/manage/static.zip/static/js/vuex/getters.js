// 获取派生出一些状态
export default {

}